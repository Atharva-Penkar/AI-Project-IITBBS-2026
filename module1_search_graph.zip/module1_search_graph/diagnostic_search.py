"""
Team 1 - Part A (Person B): Graph-search algorithms over the knowledge graph
and the diagnostic engine that returns ranked likely causes + resources.
"""
import re
from collections import deque
from dataclasses import dataclass
from typing import Dict, List, Optional
from knowledge_graph import KnowledgeGraph, build_search_syllabus

DEFAULT_MASTERY = 0.5


@dataclass
class Cause:
    concept_id: str
    concept_name: str
    score: float
    depth: int
    path: List[str]                  # target -> ... -> cause
    matched_misconception: Optional[str]
    reasons: List[str]
    resources: List[Dict[str, str]]


def _tokens(text: str) -> set:
    return set(re.findall(r"[a-z0-9()*]+", text.lower()))


# ---------- graph-search algorithms ----------
def trace_prereqs_bfs(g: KnowledgeGraph, target: str, max_depth: int = 10) -> Dict[str, dict]:
    """BFS over prerequisite edges. Returns {concept: {depth, path, strength}}.
    Keeps the shallowest path; strength = product of edge strengths along it."""
    if target not in g.concepts:
        raise KeyError(f"Unknown concept: {target}")
    found = {target: {"depth": 0, "path": [target], "strength": 1.0}}
    q = deque([target])
    while q:
        cur = q.popleft()
        info = found[cur]
        if info["depth"] >= max_depth:
            continue
        for pre, w in g.concepts[cur].prereqs.items():
            if pre not in found:
                found[pre] = {"depth": info["depth"] + 1, "path": info["path"] + [pre],
                              "strength": info["strength"] * w}
                q.append(pre)
    return found


def prereq_chain_dfs(g: KnowledgeGraph, target: str) -> List[str]:
    """DFS post-order = a valid study order (prerequisites first)."""
    order, seen = [], set()
    def visit(n):
        seen.add(n)
        for p in g.concepts[n].prereqs:
            if p not in seen:
                visit(p)
        order.append(n)
    visit(target)
    return order


# ---------- diagnosis ----------
class DiagnosticEngine:
    W_MISCONCEPTION, W_MASTERY, W_PROXIMITY = 0.5, 0.3, 0.2

    def __init__(self, graph: Optional[KnowledgeGraph] = None):
        self.g = graph or build_search_syllabus()

    def _best_misconception(self, concept_id: str, difficulty: str):
        words = _tokens(difficulty)
        best, best_score = None, 0.0
        for m in self.g.concepts[concept_id].misconceptions:
            kws = {k.lower() for k in m.keywords}
            # a multi-word keyword counts if it appears as a phrase
            hits = sum(1 for k in kws if (k in difficulty.lower()) or (k in words))
            score = hits / max(len(kws), 1)
            score = min(1.0, score * 2.5)          # a few hits are enough
            if score > best_score:
                best, best_score = m, score
        return best, best_score

    def diagnose(self, concept: str, difficulty: str,
                 mastery: Optional[Dict[str, float]] = None, top_k: int = 5) -> List[Cause]:
        mastery = mastery or {}
        reachable = trace_prereqs_bfs(self.g, concept)
        causes = []
        for cid, info in reachable.items():
            m, m_score = self._best_misconception(cid, difficulty)
            low_mastery = 1.0 - mastery.get(cid, DEFAULT_MASTERY)
            proximity = info["strength"] / (1 + 0.25 * info["depth"])
            if cid == concept:
                proximity *= 0.3     # the target is the symptom, not a root cause
            score = (self.W_MISCONCEPTION * m_score +
                     self.W_MASTERY * low_mastery +
                     self.W_PROXIMITY * proximity)
            if m_score == 0 and cid not in mastery and cid != concept:
                score *= 0.6                        # no evidence for this cause
            reasons = []
            if m:
                reasons.append(f"Difficulty matches known misconception: \"{m.text}\"")
            if cid in mastery and mastery[cid] < 0.5:
                reasons.append(f"Low mastery recorded ({mastery[cid]:.0%})")
            if info["depth"] > 0:
                reasons.append(f"Prerequisite {info['depth']} step(s) below {concept}")
            c = self.g.concepts[cid]
            causes.append(Cause(cid, c.name, round(score, 4), info["depth"], info["path"],
                                m.text if m else None, reasons,
                                [{"kind": r.kind, "title": r.title} for r in c.resources]))
        causes.sort(key=lambda c: (-c.score, c.depth))
        return causes[:top_k]

    def recommend(self, concept: str, difficulty: str, mastery=None, top_k: int = 3) -> dict:
        causes = self.diagnose(concept, difficulty, mastery, top_k=top_k + 2)
        return {"concept": concept, "difficulty": difficulty,
                "ranked_causes": causes[:top_k],
                "study_order": [c for c in prereq_chain_dfs(self.g, concept)
                                if c in {x.concept_id for x in causes[:top_k]}]}


if __name__ == "__main__":
    eng = DiagnosticEngine()
    out = eng.recommend("astar",
        "My A* returned a longer path. I think a bigger heuristic is better, so I used h(n) larger than the real cost.",
        mastery={"admissible": 0.2, "heuristic": 0.4})
    print(f"Concept: {out['concept']}\nDifficulty: {out['difficulty']}\n")
    for i, c in enumerate(out["ranked_causes"], 1):
        print(f"{i}. {c.concept_name}  (score {c.score}, depth {c.depth})")
        for r in c.reasons: print("   -", r)
        for r in c.resources: print(f"   > [{r['kind']}] {r['title']}")
    print("\nSuggested study order:", " -> ".join(out["study_order"]))
