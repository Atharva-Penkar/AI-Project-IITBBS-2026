from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class Misconception:
    id: str
    text: str
    keywords: List[str]          # words a student's complaint might contain


@dataclass
class Resource:
    kind: str                    # "concept" | "example" | "exercise"
    title: str


@dataclass
class Concept:
    id: str
    name: str
    description: str
    prereqs: Dict[str, float] = field(default_factory=dict)   # prereq_id -> dependency strength (0-1]
    misconceptions: List[Misconception] = field(default_factory=list)
    resources: List[Resource] = field(default_factory=list)


class KnowledgeGraph:
    def __init__(self):
        self.concepts: Dict[str, Concept] = {}

    def add(self, c: Concept):
        self.concepts[c.id] = c

    def validate(self):
        """Every prerequisite must exist and the graph must be acyclic."""
        for c in self.concepts.values():
            for p in c.prereqs:
                if p not in self.concepts:
                    raise ValueError(f"{c.id} has unknown prereq {p}")
        state = {}
        def dfs(n):
            state[n] = 1
            for p in self.concepts[n].prereqs:
                if state.get(p) == 1:
                    raise ValueError(f"Cycle detected at {n} -> {p}")
                if p not in state:
                    dfs(p)
            state[n] = 2
        for n in self.concepts:
            if n not in state:
                dfs(n)

    def dependents(self, cid: str) -> List[str]:
        return [c.id for c in self.concepts.values() if cid in c.prereqs]


def build_search_syllabus() -> KnowledgeGraph:
    g = KnowledgeGraph()
    M, R = Misconception, Resource

    g.add(Concept("graphs", "Graphs & Trees", "Nodes, edges, adjacency lists, parent pointers.",
        misconceptions=[M("g1", "A tree and a graph search never revisit nodes.", ["revisit", "cycle", "loop", "visited"])],
        resources=[R("concept", "Graph representations (adjacency list vs matrix)"),
                   R("exercise", "Build an adjacency list from an edge list")]))
    g.add(Concept("stack_queue", "Stacks & Queues", "LIFO and FIFO containers.",
        misconceptions=[M("sq1", "Stack and queue order only affect speed, not which node is expanded.", ["order", "fifo", "lifo", "stack", "queue"])],
        resources=[R("concept", "LIFO vs FIFO"), R("exercise", "Trace BFS and DFS frontiers on a 7-node tree")]))
    g.add(Concept("priority_queue", "Priority Queues", "Container that always pops the minimum-key item (binary heap).",
        prereqs={"stack_queue": 0.6, "graphs": 0.2},
        misconceptions=[
            M("pq1", "A priority queue is just a sorted list that is sorted once at the start.", ["sorted", "sort", "resort", "update", "reorder", "priority", "queue", "heap", "pop"]),
            M("pq2", "Pop returns the first inserted item with ties broken arbitrarily without effect.", ["tie", "tiebreak", "equal", "same priority"])],
        resources=[R("concept", "Binary heaps: push/pop in O(log n)"),
                   R("example", "Dijkstra frontier as a priority queue"),
                   R("exercise", "Implement a min-heap and process 10 pushes/pops")]))
    g.add(Concept("state_space", "State-Space Formulation", "States, actions, transition model, goal test, step cost.",
        prereqs={"graphs": 0.7},
        misconceptions=[M("ss1", "The state is the same as the path taken to reach it.", ["state", "path", "action", "transition"])],
        resources=[R("concept", "Formulating the 8-puzzle and route finding"),
                   R("exercise", "Write the successor function for the 8-puzzle")]))
    g.add(Concept("path_cost", "Path Cost g(n)", "Cumulative cost of actions from the start node to n.",
        prereqs={"state_space": 0.8},
        misconceptions=[
            M("pc1", "g(n) is the number of steps, regardless of action costs.", ["cost", "steps", "weight", "g(n)", "cumulative", "edge"]),
            M("pc2", "g(n) is the cost from n to the goal.", ["goal", "remaining", "g(n)", "distance", "to goal"])],
        resources=[R("concept", "Step cost vs path cost"),
                   R("example", "Weighted route finding: Arad to Bucharest"),
                   R("exercise", "Compute g(n) along three candidate paths")]))
    g.add(Concept("bfs", "Breadth-First Search", "Expand shallowest node first using a FIFO frontier.",
        prereqs={"stack_queue": 0.8, "state_space": 0.5},
        misconceptions=[M("b1", "BFS finds the cheapest path in any graph.", ["cheapest", "optimal", "weighted", "cost"])],
        resources=[R("example", "BFS on unweighted grid"), R("exercise", "Trace BFS frontier")]))
    g.add(Concept("dfs", "Depth-First Search", "Expand deepest node first using a LIFO frontier.",
        prereqs={"stack_queue": 0.8, "state_space": 0.5},
        misconceptions=[M("d1", "DFS is always complete.", ["complete", "infinite", "loop"])],
        resources=[R("example", "DFS with and without a visited set")]))
    g.add(Concept("ucs", "Uniform-Cost Search", "Expand the node with lowest g(n) using a priority queue.",
        prereqs={"priority_queue": 0.8, "path_cost": 0.9, "bfs": 0.4},
        misconceptions=[M("u1", "UCS stops as soon as the goal is generated.", ["goal", "stop", "generated", "early", "first"])],
        resources=[R("example", "UCS vs BFS on a weighted graph"),
                   R("exercise", "Trace UCS and show when the goal is popped")]))
    g.add(Concept("heuristic", "Heuristic h(n)", "Estimate of the cheapest cost from n to the nearest goal.",
        prereqs={"state_space": 0.6, "path_cost": 0.6},
        misconceptions=[
            M("h1", "h(n) is the actual cost to the goal or any number that looks good.", ["heuristic", "h(n)", "estimate", "guess", "actual", "overestimate", "larger"]),
            M("h2", "A heuristic includes the cost already paid, g(n).", ["heuristic", "h(n)", "already", "so far", "includes", "g(n)"])],
        resources=[R("concept", "Heuristics as relaxed-problem solutions"),
                   R("example", "Manhattan vs misplaced tiles in the 8-puzzle"),
                   R("exercise", "Design a heuristic for a grid with walls")]))
    g.add(Concept("greedy", "Greedy Best-First Search", "Expand node with lowest h(n).",
        prereqs={"heuristic": 0.9, "priority_queue": 0.7},
        misconceptions=[M("gr1", "Greedy best-first is optimal because it always follows the best-looking node.", ["optimal", "greedy", "best", "shortest"])],
        resources=[R("example", "Greedy getting trapped by a dead end")]))
    g.add(Concept("admissible", "Admissibility & Consistency", "h never overestimates; h(n) <= c(n,n') + h(n').",
        prereqs={"heuristic": 0.9, "path_cost": 0.6},
        misconceptions=[
            M("a1", "Admissible means h is exactly right or the larger the better.", ["admissible", "overestimate", "larger", "bigger", "never", "exact", "optimal"]),
            M("a2", "Consistency and admissibility are the same thing.", ["consistent", "consistency", "triangle", "same"])],
        resources=[R("concept", "Proof that admissible h gives optimal A* (tree search)"),
                   R("example", "An inadmissible heuristic returning a suboptimal path"),
                   R("exercise", "Check admissibility and consistency on a small graph")]))
    g.add(Concept("astar", "A* Search", "Expand node with lowest f(n) = g(n) + h(n) using a priority queue.",
        prereqs={"ucs": 0.7, "greedy": 0.5, "heuristic": 0.9, "admissible": 0.8, "priority_queue": 0.7, "path_cost": 0.8},
        misconceptions=[
            M("as1", "f(n) = h(n); g(n) is not needed.", ["f(n)", "g(n)", "h(n)", "ignore", "only", "sum"]),
            M("as2", "A* stops when the goal is first added to the frontier.", ["stop", "goal", "generated", "early", "first", "terminate"]),
            M("as3", "A* is always optimal regardless of heuristic.", ["always optimal", "regardless", "any heuristic"]),
            M("as4", "Once a node is expanded it never needs reopening.", ["reopen", "closed", "visited", "revisit", "explored"])],
        resources=[R("concept", "A* algorithm and optimality conditions"),
                   R("example", "Step-by-step A* on a weighted graph"),
                   R("exercise", "Trace A* with a priority queue table (g, h, f)")]))
    g.validate()
    return g
