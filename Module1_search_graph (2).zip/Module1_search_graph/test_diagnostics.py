"""Tests for graph structure and diagnostic recommendations."""
import unittest
from knowledge_graph import build_search_syllabus
from diagnostic_search import DiagnosticEngine, trace_prereqs_bfs, prereq_chain_dfs


class TestGraph(unittest.TestCase):
    def setUp(self):
        self.g = build_search_syllabus()
        self.eng = DiagnosticEngine(self.g)

    def test_graph_valid_and_acyclic(self):
        self.g.validate()

    def test_astar_prereqs_reachable(self):
        r = trace_prereqs_bfs(self.g, "astar")
        for c in ["heuristic", "path_cost", "priority_queue", "admissible", "stack_queue", "graphs"]:
            self.assertIn(c, r)

    def test_study_order_prereqs_first(self):
        order = prereq_chain_dfs(self.g, "astar")
        for c in self.g.concepts.values():
            if c.id in order:
                for p in c.prereqs:
                    self.assertLess(order.index(p), order.index(c.id))

    def test_unknown_concept(self):
        with self.assertRaises(KeyError):
            self.eng.diagnose("nope", "x")


class TestAStarFailures(unittest.TestCase):
    def setUp(self):
        self.eng = DiagnosticEngine()

    def ids(self, concept, text, mastery=None, k=3):
        return [c.concept_id for c in self.eng.diagnose(concept, text, mastery, top_k=k)]

    # --- heuristic confusion ---
    def test_overestimating_heuristic(self):
        top = self.ids("astar", "A* gave a suboptimal path because my h(n) overestimates, I thought a larger heuristic is better")
        self.assertIn("admissible", top[:2])

    def test_heuristic_includes_g(self):
        top = self.ids("astar", "my heuristic h(n) already includes the cost so far g(n)", {"heuristic": 0.3})
        self.assertIn("heuristic", top[:2])

    # --- path-cost confusion ---
    def test_steps_instead_of_cost(self):
        top = self.ids("astar", "I count the number of steps instead of the edge weight cost for g(n)", {"path_cost": 0.3})
        self.assertEqual(top[0], "path_cost")

    def test_g_as_cost_to_goal(self):
        top = self.ids("astar", "I used g(n) as the remaining distance to the goal", {"path_cost": 0.4})
        self.assertIn("path_cost", top[:2])

    # --- priority-queue confusion ---
    def test_queue_not_resorted(self):
        top = self.ids("astar", "I sorted the priority queue once and never re-sorted after inserting new nodes", {"priority_queue": 0.2})
        self.assertEqual(top[0], "priority_queue")

    def test_tie_breaking(self):
        top = self.ids("astar", "nodes with equal f get popped in a weird tie order", {"priority_queue": 0.4})
        self.assertIn("priority_queue", top[:2])

    # --- A*-specific ---
    def test_early_termination(self):
        # UCS (a prerequisite) shares this misconception, so both A* and UCS are valid causes.
        res = self.eng.diagnose("astar", "I stop A* as soon as the goal is generated, first time it appears", top_k=2)
        self.assertEqual({c.concept_id for c in res}, {"astar", "ucs"})
        self.assertTrue(all("goal" in c.matched_misconception.lower() for c in res))

    def test_mastery_drives_ranking_when_text_vague(self):
        top = self.ids("astar", "my search is wrong", {"admissible": 0.05})
        self.assertEqual(top[0], "admissible")

    # --- output contract ---
    def test_result_has_resources_and_ranking(self):
        res = self.eng.diagnose("astar", "heuristic confusion")
        self.assertTrue(all(r.resources for r in res))
        self.assertEqual([c.score for c in res], sorted([c.score for c in res], reverse=True))


if __name__ == "__main__":
    unittest.main(verbosity=2)
